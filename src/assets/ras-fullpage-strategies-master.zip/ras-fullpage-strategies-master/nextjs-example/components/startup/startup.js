import React from 'react';
import ReactLogo from '../react-logo/react-logo';
import './startup.scss';

const Startup = () => {
  return (
    <div className="startup">
      <ReactLogo />
    </div>
  );
};

export default Startup;
