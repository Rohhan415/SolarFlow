import React from "react";
import FullpageSlider from "../components/fullpage/fullpage";

const Home = () => {
  return <FullpageSlider />;
};

export default Home;
