import React from "react";
import FullpageSlider from "../components/fullpage/fullpage";

const PageThree = () => {
  return <FullpageSlider />;
};

export default PageThree;
