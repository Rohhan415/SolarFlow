import React from "react";
import FullpageSlider from "../components/fullpage/fullpage";

const PageTwo = () => {
  return <FullpageSlider />;
};

export default PageTwo;
